
This project can be opened with Unity Pro v13.

Usage in Matlab:
>> cd 'to folder containing mem_log*.DAT or mem_log*.DTX'
>> mem_dump_load_tst
